// javascript file create as exported for addon [Html Import], collection [Html Import] in site [app200509]
$(function(){
    console.log("html import ready");
    $("#hiImportTypeid").on("change",function(){
        console.log("import type change");
        var importTypeId = $('#hiImportTypeid').find(":selected").val();
        console.log("importTypeId [" + importTypeId + "]");
    })
})